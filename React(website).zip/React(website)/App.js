// App.js
import React from 'react';
import { Routes, Route } from 'react-router-dom'; // Import Routes and Route
import Navbar from './components/Navbar'; // Import Navbar component
import Footer from './components/Footer'; // Import Footer component
import Home from './pages/Home'; // Import Home page component
import AboutMe from './pages/AboutMe'; // Import About Me page component
import Projects from './pages/Projects'; // Import Projects page component
import Services from './pages/Services'; // Import Services page component
import ContactMe from './pages/ContactMe'; // Import Contact Me page component

function App() {
  return (
    <div>
      <Navbar /> {/* Render the Navbar */}
      <Routes>
        <Route path="/" element={<Home />} /> {/* Home Page */}
        <Route path="/about" element={<AboutMe />} /> {/* About Me Page */}
        <Route path="/projects" element={<Projects />} /> {/* Projects Page */}
        <Route path="/services" element={<Services />} /> {/* Services Page */}
        <Route path="/contact" element={<ContactMe />} /> {/* Contact Me Page */}
      </Routes>
      <Footer /> {/* Render the Footer */}
    </div>
  );
}

export default App;
