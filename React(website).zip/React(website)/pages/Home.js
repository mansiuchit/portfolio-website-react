// pages/Home.js
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to My Portfolio</h1>
      <p>This is my personal portfolio website.</p>
      <p>Mission Statement: To create impactful and user-friendly applications.</p>
    </div>
  );
}

export default Home;
