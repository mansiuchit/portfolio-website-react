// pages/Projects.js
import React from 'react';

function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <div>
        <h2>Project 1</h2>
        <img src="path_to_project_image_1.jpg" alt="Project 1" />
        <p>Description of Project 1 and your role.</p>
      </div>
      <div>
        <h2>Project 2</h2>
        <img src="path_to_project_image_2.jpg" alt="Project 2" />
        <p>Description of Project 2 and your role.</p>
      </div>
      <div>
        <h2>Project 3</h2>
        <img src="path_to_project_image_3.jpg" alt="Project 3" />
        <p>Description of Project 3 and your role.</p>
      </div>
    </div>
  );
}

export default Projects;
