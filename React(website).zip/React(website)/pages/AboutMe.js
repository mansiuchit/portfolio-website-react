// pages/AboutMe.js
import React from 'react';

function AboutMe() {
  return (
    <div>
      <h1>About Me</h1>
      <p>Legal Name: Your Name</p>
      <img src="path_to_your_image.jpg" alt="Your Name" />
      <p>A short paragraph about who you are.</p>
      <a href="path_to_your_resume.pdf" target="_blank" rel="noopener noreferrer">Download My Resume</a>
    </div>
  );
}

export default AboutMe;
